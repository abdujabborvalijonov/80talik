# Web3.js + MetaMask + Hardhat topshiriq paketi

Ushbu loyiha quyidagi topshiriqlarni bajaradi:

1. Web3.js kutubxonasini o‘rnatish
2. Localhost tarmog‘ini MetaMask'ka ulash
3. Smart-kontrakt ABI faylini loyihaga yuklash
4. Kontrakt adresi orqali kontrakt obyekti yaratish
5. View funksiyani chaqirib natijani konsolga chiqarish
6. `send()` metodi orqali tranzaksiya yuborish
7. Error handling yozish
8. Gas limit va gas price parametrlarini sozlash

## 1. O‘rnatish

Terminalda:

```bash
npm install
```

## 2. Hardhat lokal tarmoqni ishga tushirish

```bash
npx hardhat node
```

Bu komandadan keyin terminalda test accountlar va private keylar chiqadi.

## 3. Kontraktni deploy qilish

Yangi terminal ochib:

```bash
npx hardhat compile
npx hardhat run scripts/deploy.js --network localhost
```

Natijada:
- `abi/StorageABI.json` hosil bo‘ladi
- `public/contract-config.js` hosil bo‘ladi
- kontrakt adresi terminalda chiqadi

## 4. MetaMask'ni localhost'ga ulash

MetaMask ichida Custom network qo‘shiladi:

- Network Name: Hardhat Localhost
- RPC URL: `http://127.0.0.1:8545`
- Chain ID: `31337`
- Currency Symbol: ETH

So‘ng Hardhat node terminalidagi private keylardan birini MetaMask'ga import qilasiz.

## 5. Frontendni ishga tushirish

```bash
npm run serve
```

Brauzerda oching:

```text
http://127.0.0.1:8080
```

## 6. Domlaga ko‘rsatish tartibi

### A) Web3.js o‘rnatilganini ko‘rsatish
`package.json` ichida `web3` dependency bor

### B) ABI yuklanganini ko‘rsatish
`abi/StorageABI.json` faylini ko‘rsating

### C) Kontrakt obyekt yaratish
`public/app.js` ichida:

```js
contract = new web3.eth.Contract(
  window.CONTRACT_CONFIG.abi,
  window.CONTRACT_CONFIG.address
);
```

### D) View funksiyani chaqirish
`public/app.js` ichida:

```js
const result = await contract.methods.getValue().call();
console.log(result);
```

### E) Send orqali tranzaksiya yuborish
`public/app.js` ichida:

```js
const receipt = await tx.send({
  from: userAccount,
  gas: gasLimit || estimatedGas,
  gasPrice: gasPrice
});
```

### F) Error handling
`public/app.js` ichida:

```js
function showError(error) {
  const msg = error?.message || error?.toString() || "Noma'lum xatolik";
  alert(`Xatolik yuz berdi: ${msg}`);
}
```

### G) Gas limit va gas price
Forma ichida qo‘lda kiritilib yuboriladi

## 7. Eslatma
Agar MetaMask tarmoqni ulashda muammo bersa, avval eski localhost networkni o‘chirib, qaytadan `31337` chain ID bilan qo‘shing.
