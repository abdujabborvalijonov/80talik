// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

contract Storage {
    uint256 private value;
    address public lastSender;

    event ValueUpdated(uint256 newValue, address indexed sender);

    constructor(uint256 initialValue) {
        value = initialValue;
        lastSender = msg.sender;
    }

    function getValue() public view returns (uint256) {
        return value;
    }

    function setValue(uint256 newValue) public {
        value = newValue;
        lastSender = msg.sender;
        emit ValueUpdated(newValue, msg.sender);
    }
}
