let web3;
let userAccount;
let contract;

const accountEl = document.getElementById("account");
const networkInfoEl = document.getElementById("networkInfo");
const readResultEl = document.getElementById("readResult");
const txHashEl = document.getElementById("txHash");
const logEl = document.getElementById("log");

function log(message, data = "") {
  const text = typeof data === "object" ? JSON.stringify(data, null, 2) : data;
  logEl.textContent += `[${new Date().toLocaleTimeString()}] ${message} ${text}\n`;
  console.log(message, data || "");
}

function showError(error) {
  const msg = error?.message || error?.toString() || "Noma'lum xatolik";
  log("XATOLIK:", msg);
  alert(`Xatolik yuz berdi: ${msg}`);
}

async function connectMetaMask() {
  try {
    if (!window.ethereum) {
      throw new Error("MetaMask topilmadi. Brauzerga MetaMask o‘rnating.");
    }

    const accounts = await window.ethereum.request({
      method: "eth_requestAccounts"
    });

    web3 = new Web3(window.ethereum);
    userAccount = accounts[0];
    accountEl.textContent = userAccount;

    const chainId = await web3.eth.getChainId();
    networkInfoEl.textContent = `Chain ID: ${chainId}`;

    contract = new web3.eth.Contract(
      window.CONTRACT_CONFIG.abi,
      window.CONTRACT_CONFIG.address
    );

    log("MetaMask ulandi.");
    log("Kontrakt adresi:", window.CONTRACT_CONFIG.address);
    log("ABI yuklandi va kontrakt obyekti yaratildi.");
  } catch (error) {
    showError(error);
  }
}

async function readValue() {
  try {
    if (!contract) {
      throw new Error("Avval MetaMask'ni ulang.");
    }

    const result = await contract.methods.getValue().call();
    readResultEl.textContent = result.toString();
    log("getValue() natijasi:", result.toString());
  } catch (error) {
    showError(error);
  }
}

async function sendTransaction() {
  try {
    if (!contract || !userAccount) {
      throw new Error("Avval MetaMask'ni ulang.");
    }

    const newValue = document.getElementById("newValue").value;
    const gasLimit = document.getElementById("gasLimit").value;
    const gasPrice = document.getElementById("gasPrice").value;

    const tx = contract.methods.setValue(newValue);

    const estimatedGas = await tx.estimateGas({ from: userAccount });
    log("estimateGas():", estimatedGas.toString());

    const receipt = await tx.send({
      from: userAccount,
      gas: gasLimit || estimatedGas,
      gasPrice: gasPrice
    });

    txHashEl.textContent = receipt.transactionHash;
    log("Tranzaksiya muvaffaqiyatli yuborildi.");
    log("Receipt:", receipt);
  } catch (error) {
    showError(error);
  }
}

document.getElementById("connectBtn").addEventListener("click", connectMetaMask);
document.getElementById("readBtn").addEventListener("click", readValue);
document.getElementById("sendBtn").addEventListener("click", sendTransaction);

if (window.ethereum) {
  window.ethereum.on("accountsChanged", (accounts) => {
    userAccount = accounts[0] || null;
    accountEl.textContent = userAccount || "Ulanmagan";
    log("Account o'zgardi:", userAccount || "yo'q");
  });

  window.ethereum.on("chainChanged", () => {
    location.reload();
  });
}
