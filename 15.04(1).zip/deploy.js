import hre from "hardhat";
import fs from "fs";
import path from "path";

async function main() {
  const Storage = await hre.ethers.getContractFactory("Storage");
  const storage = await Storage.deploy(100);
  await storage.waitForDeployment();

  const contractAddress = await storage.getAddress();
  const artifact = await hre.artifacts.readArtifact("Storage");

  const abiDir = path.join(process.cwd(), "abi");
  const publicDir = path.join(process.cwd(), "public");
  fs.mkdirSync(abiDir, { recursive: true });
  fs.mkdirSync(publicDir, { recursive: true });

  fs.writeFileSync(
    path.join(abiDir, "StorageABI.json"),
    JSON.stringify(artifact.abi, null, 2)
  );

  fs.writeFileSync(
    path.join(publicDir, "contract-config.js"),
    `window.CONTRACT_CONFIG = ${JSON.stringify({
      address: contractAddress,
      abi: artifact.abi
    }, null, 2)};\n`
  );

  console.log("Storage kontrakti deploy qilindi:", contractAddress);
  console.log("ABI saqlandi: abi/StorageABI.json");
  console.log("Frontend config saqlandi: public/contract-config.js");
}

main().catch((error) => {
  console.error("Deploy xatoligi:", error);
  process.exitCode = 1;
});
