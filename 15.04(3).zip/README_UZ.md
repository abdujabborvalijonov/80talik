# Shifoxonada navbat olish smart-kontrakti

Ushbu loyiha topshiriqdagi barcha talablarni bajaradi:

1. **Shifoxonada navbat olish smart-kontrakti tuzilgan**
2. **payable funksiya qo‘shilgan** → `takeQueue()`
3. **Faqat ma'lum adresdan to‘lov qabul qilinadi** → `allowedPayer`
4. **Minimal to‘lov require bilan tekshiriladi** → `msg.value >= minPayment`
5. **Shart bajarilsa mablag‘ boshqa adresga o‘tkaziladi** → `hospitalWallet`
6. **if/else yordamida turli holatlar ishlatilgan**
   - `msg.value >= minPayment * 2` → VIP navbat
   - aks holda → oddiy navbat
7. **mapping yordamida foydalanuvchi balansi saqlanadi** → `balances`
8. **Faqat owner pul yechib oladi** → `ownerWithdraw()`
9. **To‘lov bo‘lganda event chiqariladi** → `PaymentProcessed`

## Loyiha tuzilmasi

- `contracts/HospitalQueue.sol` — asosiy smart-kontrakt
- `scripts/deploy.js` — deploy script
- `test/HospitalQueue.js` — testlar
- `hardhat.config.js` — Hardhat konfiguratsiyasi

## Ishga tushirish

### 1. Kutubxonalarni o‘rnatish

```bash
npm install
```

### 2. Kontraktni compile qilish

```bash
npm run compile
```

### 3. Local blockchain ishga tushirish

```bash
npm run node
```

### 4. Yangi terminalda deploy qilish

```bash
npm run deploy:localhost
```

### 5. Testlarni ishga tushirish

```bash
npm test
```

## Domlaga qisqa tushuntirish

Bu kontrakt shifoxonada navbat olish jarayonini modellashtiradi. `takeQueue()` funksiyasi orqali foydalanuvchi to‘lov qiladi. Kontrakt faqat oldindan ruxsat berilgan bitta adresdan kelgan to‘lovni qabul qiladi. To‘lov miqdori minimal summadan kam bo‘lsa, tranzaksiya bekor qilinadi. Agar to‘lov yetarli bo‘lsa, mablag‘ shifoxona hamyoniga o‘tkaziladi. `if/else` yordamida to‘lov miqdoriga qarab oddiy yoki VIP navbat belgilanadi. `mapping` orqali foydalanuvchi to‘lovlari saqlanadi. Kontraktda qolgan mablag‘ni faqat owner yechib olishi mumkin. Har bir muvaffaqiyatli to‘lovdan keyin event chiqariladi.
