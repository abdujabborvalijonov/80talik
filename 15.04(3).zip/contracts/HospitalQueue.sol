// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

/**
 * @title HospitalQueue
 * @notice Simple hospital appointment queue contract with payment validation,
 * forwarding logic, user balances, owner-only withdrawal, and events.
 */
contract HospitalQueue {
    address public owner;
    address payable public hospitalWallet;
    address public allowedPayer;
    uint256 public minPayment;

    enum QueueType {
        None,
        Standard,
        VIP
    }

    struct PatientPayment {
        uint256 totalPaid;
        uint256 queueCount;
        QueueType lastQueueType;
    }

    mapping(address => uint256) public balances;
    mapping(address => PatientPayment) public patientInfo;

    event PaymentProcessed(
        address indexed payer,
        uint256 amount,
        QueueType queueType,
        address indexed forwardedTo
    );
    event OwnerWithdrawal(address indexed owner, uint256 amount);
    event AllowedPayerUpdated(address indexed oldPayer, address indexed newPayer);
    event HospitalWalletUpdated(address indexed oldWallet, address indexed newWallet);
    event MinPaymentUpdated(uint256 oldAmount, uint256 newAmount);

    modifier onlyOwner() {
        require(msg.sender == owner, "Only owner can call this function");
        _;
    }

    constructor(address _allowedPayer, address payable _hospitalWallet, uint256 _minPayment) {
        require(_allowedPayer != address(0), "Allowed payer cannot be zero");
        require(_hospitalWallet != address(0), "Hospital wallet cannot be zero");
        require(_minPayment > 0, "Minimum payment must be greater than zero");

        owner = msg.sender;
        allowedPayer = _allowedPayer;
        hospitalWallet = _hospitalWallet;
        minPayment = _minPayment;
    }

    /**
     * @notice Main payable function for taking a hospital queue slot.
     * Requirements:
     * - only a specific allowed address may pay
     * - payment must be at least minPayment
     * Behavior:
     * - saves the user's balance in mapping
     * - forwards funds to hospitalWallet
     * - if/else assigns queue type based on amount
     * - emits event when payment succeeds
     */
    function takeQueue() external payable {
        require(msg.sender == allowedPayer, "Payment accepted only from allowed address");
        require(msg.value >= minPayment, "Payment is below minimum amount");

        balances[msg.sender] += msg.value;
        patientInfo[msg.sender].totalPaid += msg.value;
        patientInfo[msg.sender].queueCount += 1;

        QueueType queueType;

        if (msg.value >= minPayment * 2) {
            queueType = QueueType.VIP;
        } else {
            queueType = QueueType.Standard;
        }

        patientInfo[msg.sender].lastQueueType = queueType;

        (bool sent, ) = hospitalWallet.call{value: msg.value}("");
        require(sent, "Forwarding payment failed");

        emit PaymentProcessed(msg.sender, msg.value, queueType, hospitalWallet);
    }

    /**
     * @notice Owner can withdraw any ETH that remains in this contract.
     * In the normal flow, payments are forwarded immediately. This function
     * exists to satisfy the requirement that only the owner can withdraw.
     */
    function ownerWithdraw() external onlyOwner {
        uint256 contractBalance = address(this).balance;
        require(contractBalance > 0, "Contract balance is zero");

        (bool sent, ) = payable(owner).call{value: contractBalance}("");
        require(sent, "Owner withdrawal failed");

        emit OwnerWithdrawal(owner, contractBalance);
    }

    function updateAllowedPayer(address _newAllowedPayer) external onlyOwner {
        require(_newAllowedPayer != address(0), "Allowed payer cannot be zero");
        address oldPayer = allowedPayer;
        allowedPayer = _newAllowedPayer;
        emit AllowedPayerUpdated(oldPayer, _newAllowedPayer);
    }

    function updateHospitalWallet(address payable _newHospitalWallet) external onlyOwner {
        require(_newHospitalWallet != address(0), "Hospital wallet cannot be zero");
        address oldWallet = hospitalWallet;
        hospitalWallet = _newHospitalWallet;
        emit HospitalWalletUpdated(oldWallet, _newHospitalWallet);
    }

    function updateMinPayment(uint256 _newMinPayment) external onlyOwner {
        require(_newMinPayment > 0, "Minimum payment must be greater than zero");
        uint256 oldMinPayment = minPayment;
        minPayment = _newMinPayment;
        emit MinPaymentUpdated(oldMinPayment, _newMinPayment);
    }

    function getMyPaymentSummary()
        external
        view
        returns (uint256 totalPaid, uint256 queueCount, QueueType lastQueueType)
    {
        PatientPayment memory info = patientInfo[msg.sender];
        return (info.totalPaid, info.queueCount, info.lastQueueType);
    }
}
