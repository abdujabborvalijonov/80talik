const hre = require("hardhat");

async function main() {
  const [deployer, allowedPayer, hospitalWallet] = await hre.ethers.getSigners();

  console.log("Deployer:", deployer.address);
  console.log("Allowed payer:", allowedPayer.address);
  console.log("Hospital wallet:", hospitalWallet.address);

  const minPayment = hre.ethers.parseEther("0.01");

  const Factory = await hre.ethers.getContractFactory("HospitalQueue");
  const contract = await Factory.deploy(
    allowedPayer.address,
    hospitalWallet.address,
    minPayment
  );

  await contract.waitForDeployment();

  console.log("HospitalQueue deployed to:", await contract.getAddress());
  console.log("Minimum payment:", hre.ethers.formatEther(minPayment), "ETH");
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
