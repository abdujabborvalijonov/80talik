const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("HospitalQueue", function () {
  async function deployFixture() {
    const [owner, allowedPayer, hospitalWallet, otherUser] = await ethers.getSigners();
    const minPayment = ethers.parseEther("0.01");

    const Factory = await ethers.getContractFactory("HospitalQueue");
    const contract = await Factory.deploy(
      allowedPayer.address,
      hospitalWallet.address,
      minPayment
    );

    await contract.waitForDeployment();
    return { contract, owner, allowedPayer, hospitalWallet, otherUser, minPayment };
  }

  it("sets constructor values correctly", async function () {
    const { contract, owner, allowedPayer, hospitalWallet, minPayment } = await deployFixture();
    expect(await contract.owner()).to.equal(owner.address);
    expect(await contract.allowedPayer()).to.equal(allowedPayer.address);
    expect(await contract.hospitalWallet()).to.equal(hospitalWallet.address);
    expect(await contract.minPayment()).to.equal(minPayment);
  });

  it("rejects payment from unauthorized address", async function () {
    const { contract, otherUser, minPayment } = await deployFixture();
    await expect(contract.connect(otherUser).takeQueue({ value: minPayment }))
      .to.be.revertedWith("Payment accepted only from allowed address");
  });

  it("rejects payment below minimum", async function () {
    const { contract, allowedPayer } = await deployFixture();
    await expect(contract.connect(allowedPayer).takeQueue({ value: ethers.parseEther("0.001") }))
      .to.be.revertedWith("Payment is below minimum amount");
  });

  it("processes standard queue payment and stores balance", async function () {
    const { contract, allowedPayer, hospitalWallet, minPayment } = await deployFixture();
    const hospitalBefore = await ethers.provider.getBalance(hospitalWallet.address);

    const tx = await contract.connect(allowedPayer).takeQueue({ value: minPayment });
    await expect(tx)
      .to.emit(contract, "PaymentProcessed");

    const hospitalAfter = await ethers.provider.getBalance(hospitalWallet.address);
    expect(hospitalAfter - hospitalBefore).to.equal(minPayment);
    expect(await contract.balances(allowedPayer.address)).to.equal(minPayment);

    const summary = await contract.connect(allowedPayer).getMyPaymentSummary();
    expect(summary[0]).to.equal(minPayment);
    expect(summary[1]).to.equal(1n);
    expect(summary[2]).to.equal(1n); // Standard
  });

  it("processes VIP queue payment with if/else branch", async function () {
    const { contract, allowedPayer, minPayment } = await deployFixture();
    const vipPayment = minPayment * 2n;
    await contract.connect(allowedPayer).takeQueue({ value: vipPayment });

    const summary = await contract.connect(allowedPayer).getMyPaymentSummary();
    expect(summary[2]).to.equal(2n); // VIP
  });

  it("allows only owner to withdraw remaining contract funds", async function () {
    const { contract, owner, otherUser } = await deployFixture();
    await owner.sendTransaction({
      to: await contract.getAddress(),
      value: ethers.parseEther("1")
    });

    await expect(contract.connect(otherUser).ownerWithdraw())
      .to.be.revertedWith("Only owner can call this function");

    await expect(contract.connect(owner).ownerWithdraw())
      .to.emit(contract, "OwnerWithdrawal");
  });
});
