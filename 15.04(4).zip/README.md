# Blockchain Assignment Project

Bu loyiha quyidagi topshiriqlarni bajaradi:

1. `Block` klassi yaratilgan (`index`, `timestamp`, `data`, `hash`, `previous_hash`, `nonce`)
2. SHA-256 hash hisoblash funksiyasi yozilgan
3. Genesis blok yaratilgan
4. Yangi blok qo'shish funksiyasi yozilgan
5. Har bir blok `previous_hash` orqali oldingi blok bilan bog'langan
6. Blockchain massiv (`chain`) ko'rinishida tashkil qilingan
7. Zanjirni tekshiruvchi `is_chain_valid()` funksiyasi yozilgan
8. Ma'lumot o'zgarsa zanjir buzilishi tekshirilgan
9. Oddiy Proof-of-Work (mining) qo'shilgan
10. Konsolda bloklar ro'yxatini chiqaruvchi dastur tayyorlangan

## Ishga tushirish

```bash
python main.py
```

## Konsolda nima bo'ladi

- Genesis blok yaratiladi
- 3 ta yangi blok mining qilinib qo'shiladi
- Barcha bloklar konsolda chiqariladi
- Zanjir validatsiya qilinadi
- Keyin bitta blok ichidagi ma'lumot ataylab o'zgartiriladi
- Zanjir buzilgani ko'rsatiladi

## GitHub'ga yuklash

1. ZIP faylni oching
2. Papkani GitHub repository ichiga joylang
3. `git add .`
4. `git commit -m "Add blockchain assignment project"`
5. `git push`
