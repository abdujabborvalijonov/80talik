import hashlib
import json
import time
from dataclasses import dataclass, field
from typing import List


@dataclass
class Block:
    index: int
    timestamp: float
    data: str
    previous_hash: str
    nonce: int = 0
    hash: str = field(init=False)

    def __post_init__(self):
        self.hash = self.calculate_hash()

    def calculate_hash(self) -> str:
        """Blok ma'lumotlaridan SHA-256 hash yaratadi."""
        block_string = json.dumps(
            {
                "index": self.index,
                "timestamp": self.timestamp,
                "data": self.data,
                "previous_hash": self.previous_hash,
                "nonce": self.nonce,
            },
            sort_keys=True,
        )
        return hashlib.sha256(block_string.encode("utf-8")).hexdigest()

    def mine_block(self, difficulty: int) -> None:
        """Proof-of-Work: hash boshida difficulty ta nol bo'lguncha nonce oshiriladi."""
        target = "0" * difficulty
        while not self.hash.startswith(target):
            self.nonce += 1
            self.hash = self.calculate_hash()


class Blockchain:
    def __init__(self, difficulty: int = 4):
        self.difficulty = difficulty
        self.chain: List[Block] = [self.create_genesis_block()]

    def create_genesis_block(self) -> Block:
        """Birinchi, boshlang'ich blok."""
        genesis_block = Block(
            index=0,
            timestamp=time.time(),
            data="Genesis Block",
            previous_hash="0",
        )
        genesis_block.mine_block(self.difficulty)
        return genesis_block

    def get_latest_block(self) -> Block:
        return self.chain[-1]

    def add_block(self, data: str) -> None:
        previous_block = self.get_latest_block()
        new_block = Block(
            index=previous_block.index + 1,
            timestamp=time.time(),
            data=data,
            previous_hash=previous_block.hash,
        )
        print(f"Yangi blok mining qilinmoqda: #{new_block.index}")
        new_block.mine_block(self.difficulty)
        self.chain.append(new_block)
        print(f"Blok qo'shildi: #{new_block.index} | Hash: {new_block.hash}\n")

    def is_chain_valid(self) -> bool:
        for i in range(1, len(self.chain)):
            current_block = self.chain[i]
            previous_block = self.chain[i - 1]

            if current_block.hash != current_block.calculate_hash():
                print(f"Xatolik: {current_block.index}-blok hash noto'g'ri.")
                return False

            if current_block.previous_hash != previous_block.hash:
                print(f"Xatolik: {current_block.index}-blok previous_hash noto'g'ri.")
                return False

            if not current_block.hash.startswith("0" * self.difficulty):
                print(f"Xatolik: {current_block.index}-blok Proof-of-Work shartini bajarmagan.")
                return False

        return True

    def print_chain(self) -> None:
        print("\n========== BLOCKCHAIN ==========")
        for block in self.chain:
            print(f"Index         : {block.index}")
            print(f"Timestamp     : {block.timestamp}")
            print(f"Data          : {block.data}")
            print(f"Previous Hash : {block.previous_hash}")
            print(f"Nonce         : {block.nonce}")
            print(f"Hash          : {block.hash}")
            print("-" * 40)


def run_demo() -> None:
    print("Blockchain loyihasi ishga tushdi...\n")

    blockchain = Blockchain(difficulty=4)

    blockchain.add_block("1-blok ma'lumoti: Salom, Blockchain")
    blockchain.add_block("2-blok ma'lumoti: Python orqali blok yaratildi")
    blockchain.add_block("3-blok ma'lumoti: Proof-of-Work ishlamoqda")

    blockchain.print_chain()

    print("\nZanjir holati:")
    print("Validmi? ->", blockchain.is_chain_valid())

    print("\nMa'lumot o'zgartirilmoqda (zanjirni buzish testi)...")
    blockchain.chain[1].data = "1-blok ma'lumoti: BU YERDA MA'LUMOT O'ZGARDI"

    print("Qayta tekshiruv natijasi:")
    print("Validmi? ->", blockchain.is_chain_valid())


if __name__ == "__main__":
    run_demo()
