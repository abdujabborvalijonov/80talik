# MedMint NFT DApp

MedMint NFT DApp — NFT mint qilish va tokenlarga vote berish uchun tayyor Web3 loyiha.

## Nimalar bor
- Solidity ERC-721 kontrakt
- Localhost va Sepolia deploy skriptlari
- Vanilla JS frontend
- React.js frontend
- Vote funksiyasi
- Owner withdraw
- README, arxitektura va slayd demo

## 1. O'rnatish
```bash
npm install
cd react-dapp && npm install && cd ..
```

## 2. Localhostda ishga tushirish
Terminal 1:
```bash
npm run node
```

Terminal 2:
```bash
npm run compile
npm run deploy:localhost
npm run serve:vanilla
```

Vanilla frontend:
- http://127.0.0.1:8080

React frontend:
```bash
cd react-dapp
npm run dev
```

## 3. Sepolia testnetga deploy
`.env.example` ni `.env` ga nusxalang va to'ldiring:
```env
SEPOLIA_RPC_URL=...
PRIVATE_KEY=...
ETHERSCAN_API_KEY=...
```

So'ng:
```bash
npm run compile
npm run deploy:sepolia
```

> Eslatma: real testnet deploy qilish uchun Sepolia ETH va RPC kerak. Shu zip ichida deploy skript tayyor, lekin sizning shaxsiy kalitingizsiz deploy qilinmaydi.

## 4. Frontendni kontrakt bilan bog'lash
Localhost deploy skripti avtomatik ravishda:
- `frontend-vanilla/contract-config.js`
- `react-dapp/src/abi/contract-config.json`
fayllarini yaratadi.

Sepolia uchun deploy bo'lgandan keyin contract address ni shu fayllarga qo'lda yangilang.

## 5. React frontend funksiyalari
- Wallet connect
- NFT mint
- Collection ro'yxati
- Vote berish
- Metadata URI update
- Tx status (pending/success/error)
- Network badge

## 6. GitHub
Repo ochib quyidagilarni bajaring:
```bash
git init
git add .
git commit -m "Initial MedMint NFT DApp"
git branch -M main
git remote add origin https://github.com/USERNAME/REPO.git
git push -u origin main
```

## 7. GitHub Pages / Vercel
### Vercel (React)
```bash
cd react-dapp
npm run build
```
Vercel dashboard orqali `react-dapp` papkani deploy qiling.

### GitHub Pages
`react-dapp` build natijasini Pages ga joylang yoki Vite + gh-pages paketidan foydalaning.

## 8. Demo ssenariy
1. Wallet connect qiling
2. Mint formaga token URI kiriting
3. Mint qiling
4. Token kartasida vote bosing
5. Token egasi sifatida URI update qilib ko'ring

## 9. Fayl tuzilmasi
- `contracts/MedMintNFT.sol`
- `scripts/`
- `test/`
- `frontend-vanilla/`
- `react-dapp/`
- `docs/`
- `presentation/`

## 10. Muhim cheklov
Men zip ichida **GitHub repo tayyor holatini** va **testnet deploy skriptini** berdim, lekin sizning GitHub yoki Sepolia wallet kalitlaringizsiz ularni sizning nomingizdan real deploy qilib bo'lmaydi.
