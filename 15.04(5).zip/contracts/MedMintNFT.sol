// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/token/ERC721/extensions/ERC721URIStorage.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

/**
 * @title MedMintNFT
 * @notice Simple ERC-721 collection for hospital queue / medical service NFTs.
 * Users can mint NFTs and vote for existing NFTs. Contract owner can withdraw mint fees.
 */
contract MedMintNFT is ERC721URIStorage, Ownable {
    uint256 public nextTokenId;
    uint256 public mintFee;
    uint256 public totalVotes;

    mapping(uint256 => uint256) public voteCount;
    mapping(address => mapping(uint256 => bool)) public hasVoted;
    mapping(address => uint256[]) private _mintedTokensByOwner;

    event NFTMinted(address indexed minter, uint256 indexed tokenId, string tokenURI, uint256 feePaid);
    event TokenURIUpdated(uint256 indexed tokenId, string newTokenURI);
    event Voted(address indexed voter, uint256 indexed tokenId, uint256 voteCountAfter);
    event MintFeeUpdated(uint256 oldFee, uint256 newFee);
    event FundsWithdrawn(address indexed owner, uint256 amount);

    constructor(address initialOwner, uint256 initialMintFee)
        ERC721("MedMintNFT", "MMNFT")
        Ownable(initialOwner)
    {
        mintFee = initialMintFee;
    }

    function mintNFT(string calldata tokenURI_) external payable returns (uint256 tokenId) {
        require(bytes(tokenURI_).length > 0, "Token URI required");
        require(msg.value >= mintFee, "Insufficient mint fee");

        tokenId = ++nextTokenId;
        _safeMint(msg.sender, tokenId);
        _setTokenURI(tokenId, tokenURI_);
        _mintedTokensByOwner[msg.sender].push(tokenId);

        emit NFTMinted(msg.sender, tokenId, tokenURI_, msg.value);
    }

    function vote(uint256 tokenId) external {
        require(_ownerOf(tokenId) != address(0), "Token does not exist");
        require(!hasVoted[msg.sender][tokenId], "Already voted for this token");

        hasVoted[msg.sender][tokenId] = true;
        voteCount[tokenId] += 1;
        totalVotes += 1;

        emit Voted(msg.sender, tokenId, voteCount[tokenId]);
    }

    function updateTokenURI(uint256 tokenId, string calldata newTokenURI) external {
        require(_ownerOf(tokenId) != address(0), "Token does not exist");
        require(ownerOf(tokenId) == msg.sender, "Only token owner can update URI");
        require(bytes(newTokenURI).length > 0, "New token URI required");

        _setTokenURI(tokenId, newTokenURI);
        emit TokenURIUpdated(tokenId, newTokenURI);
    }

    function setMintFee(uint256 newMintFee) external onlyOwner {
        uint256 oldFee = mintFee;
        mintFee = newMintFee;
        emit MintFeeUpdated(oldFee, newMintFee);
    }

    function withdraw() external onlyOwner {
        uint256 balance = address(this).balance;
        require(balance > 0, "No funds available");

        (bool ok, ) = payable(owner()).call{value: balance}("");
        require(ok, "Withdraw failed");

        emit FundsWithdrawn(owner(), balance);
    }

    function getTokenData(uint256 tokenId)
        external
        view
        returns (
            uint256 id,
            address tokenOwner,
            string memory uri,
            uint256 votes
        )
    {
        require(_ownerOf(tokenId) != address(0), "Token does not exist");
        return (tokenId, ownerOf(tokenId), tokenURI(tokenId), voteCount[tokenId]);
    }

    function getMintedTokensByOwner(address ownerAddress) external view returns (uint256[] memory) {
        return _mintedTokensByOwner[ownerAddress];
    }
}
