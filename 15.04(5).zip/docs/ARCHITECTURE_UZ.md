# Smart-kontrakt arxitekturasi

## Kontrakt: `MedMintNFT`
OpenZeppelin `ERC721URIStorage` asosida qurilgan.

## State
- `nextTokenId` - keyingi NFT ID
- `mintFee` - mint qilish narxi
- `totalVotes` - jami vote soni
- `voteCount[tokenId]` - token bo'yicha ovozlar
- `hasVoted[user][tokenId]` - user shu token uchun ovoz berganmi
- `_mintedTokensByOwner[user]` - foydalanuvchi mint qilgan tokenlar

## Asosiy funksiyalar
- `mintNFT(string tokenURI)` - payable mint
- `vote(uint256 tokenId)` - 1 wallet = 1 vote/token
- `updateTokenURI(uint256 tokenId, string newTokenURI)` - token egasi metadata URI yangilaydi
- `setMintFee(uint256 newMintFee)` - owner mint fee o'zgartiradi
- `withdraw()` - owner kontrakt balansini yechib oladi
- `getTokenData(uint256 tokenId)` - token ma'lumotlari
- `getMintedTokensByOwner(address user)` - userning tokenlari

## Eventlar
- `NFTMinted`
- `TokenURIUpdated`
- `Voted`
- `MintFeeUpdated`
- `FundsWithdrawn`

## Tarmoq
- Localhost (Hardhat)
- Sepolia testnet
