# Demo ssenariy

1. Hardhat node yoki Sepolia frontendni ishga tushiring.
2. Wallet connect qiling.
3. `ipfs://demo-token-1` bilan NFT mint qiling.
4. Token ro'yxatida yangi NFT paydo bo'lishini ko'rsating.
5. Vote tugmasini bosib ovoz soni oshishini ko'rsating.
6. O'sha token owner sifatida metadata URI ni yangilang.
7. React versiyasini ochib xuddi shu flow ni takrorlang.
