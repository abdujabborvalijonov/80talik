# NFT yaratish va Web3 ga joylash loyihasi rejasi

## Loyiha nomi
**MedMint NFT DApp**

## Maqsad
Foydalanuvchi wallet ulab:
1. NFT mint qiladi
2. mavjud NFTlar ro'yxatini ko'radi
3. NFTga ovoz beradi
4. kontrakt balansini owner yechib oladi

## Bosqichlar
1. Smart-kontrakt arxitekturasini loyihalash
2. Solidity kontraktini yozish
3. Localhost va Sepolia deploy skriptlari
4. Oddiy frontend (HTML/CSS/JS)
5. React.js interfeys
6. Contract/frontend integratsiyasi
7. Test va UX yaxshilash
8. GitHub README va deploy yo'riqnomasi
9. Slayd tayyorlash

## Asosiy foydalanuvchi funksiyalari
- Wallet ulash
- NFT mint qilish
- Tokenlar ro'yxatini ko'rish
- Token bo'yicha vote berish
- O'z token URI sini yangilash
- Transaction statusni ko'rish
