const connectBtn = document.getElementById('connectBtn');
const refreshBtn = document.getElementById('refreshBtn');
const mintBtn = document.getElementById('mintBtn');
const updateBtn = document.getElementById('updateBtn');
const accountPill = document.getElementById('accountPill');
const networkPill = document.getElementById('networkPill');
const feePill = document.getElementById('feePill');
const statusBox = document.getElementById('statusBox');
const tokenGrid = document.getElementById('tokenGrid');
const supplyInfo = document.getElementById('supplyInfo');

let provider;
let signer;
let contract;

function setStatus(kind, text) {
  statusBox.className = `status status-${kind}`;
  statusBox.textContent = `Holat: ${text}`;
}

async function connectWallet() {
  try {
    if (!window.ethereum) {
      alert("MetaMask yoki boshqa injected wallet topilmadi.");
      return;
    }
    provider = new ethers.BrowserProvider(window.ethereum);
    await provider.send("eth_requestAccounts", []);
    signer = await provider.getSigner();

    const { chainId, name } = await provider.getNetwork();
    contract = new ethers.Contract(window.CONTRACT_CONFIG.address, window.CONTRACT_CONFIG.abi, signer);

    accountPill.textContent = `Account: ${await signer.getAddress()}`;
    networkPill.textContent = `Network: ${name || "unknown"} (Chain ID: ${chainId})`;
    feePill.textContent = `Mint fee: ${ethers.formatEther(await contract.mintFee())} ETH`;
    setStatus("success", "wallet ulandi");
    await loadTokens();
  } catch (err) {
    console.error(err);
    setStatus("error", err.shortMessage || err.message);
  }
}

async function loadTokens() {
  try {
    if (!contract) return;
    tokenGrid.innerHTML = "";
    const nextTokenId = Number(await contract.nextTokenId());
    supplyInfo.textContent = `Jami tokenlar: ${nextTokenId}`;
    if (nextTokenId === 0) {
      tokenGrid.innerHTML = "<p class='muted'>Hali token mint qilinmagan.</p>";
      return;
    }

    for (let i = 1; i <= nextTokenId; i++) {
      const [id, owner, uri, votes] = await contract.getTokenData(i);
      const card = document.createElement("div");
      card.className = "token-card";
      card.innerHTML = `
        <h3>Token #${id}</h3>
        <p><strong>Owner:</strong> ${owner}</p>
        <p><strong>URI:</strong> ${uri}</p>
        <p><strong>Votes:</strong> ${votes}</p>
        <div class="token-actions">
          <button class="btn btn-primary vote-btn" data-id="${id}">Vote</button>
        </div>
      `;
      tokenGrid.appendChild(card);
    }

    document.querySelectorAll(".vote-btn").forEach((btn) => {
      btn.addEventListener("click", async () => {
        try {
          setStatus("pending", `Token #${btn.dataset.id} uchun vote yuborilmoqda...`);
          const tx = await contract.vote(Number(btn.dataset.id));
          await tx.wait();
          setStatus("success", `Vote muvaffaqiyatli: ${tx.hash}`);
          await loadTokens();
        } catch (err) {
          console.error(err);
          setStatus("error", err.shortMessage || err.message);
        }
      });
    });
  } catch (err) {
    console.error(err);
    setStatus("error", err.shortMessage || err.message);
  }
}

async function mintNFT() {
  try {
    if (!contract) return alert("Avval wallet ulang");
    const uri = document.getElementById("mintUri").value.trim();
    if (!uri) return alert("Token URI kiriting");

    const mintFee = await contract.mintFee();
    setStatus("pending", "Mint tranzaksiyasi yuborilmoqda...");
    const tx = await contract.mintNFT(uri, { value: mintFee });
    await tx.wait();
    setStatus("success", `Mint muvaffaqiyatli: ${tx.hash}`);
    document.getElementById("mintUri").value = "";
    await loadTokens();
  } catch (err) {
    console.error(err);
    setStatus("error", err.shortMessage || err.message);
  }
}

async function updateTokenURI() {
  try {
    if (!contract) return alert("Avval wallet ulang");
    const tokenId = Number(document.getElementById("updateTokenId").value);
    const newUri = document.getElementById("updateTokenUri").value.trim();
    if (!tokenId || !newUri) return alert("Token ID va yangi URI kiriting");

    setStatus("pending", "Token URI yangilanmoqda...");
    const tx = await contract.updateTokenURI(tokenId, newUri);
    await tx.wait();
    setStatus("success", `URI yangilandi: ${tx.hash}`);
    await loadTokens();
  } catch (err) {
    console.error(err);
    setStatus("error", err.shortMessage || err.message);
  }
}

connectBtn.addEventListener("click", connectWallet);
refreshBtn.addEventListener("click", loadTokens);
mintBtn.addEventListener("click", mintNFT);
updateBtn.addEventListener("click", updateTokenURI);

if (window.ethereum) {
  window.ethereum.on("accountsChanged", connectWallet);
  window.ethereum.on("chainChanged", () => window.location.reload());
}
