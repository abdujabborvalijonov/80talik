import { useEffect, useMemo, useState } from 'react';
import { ethers } from 'ethers';
import contractConfig from './abi/contract-config.json';

const short = (value = '') => value ? `${value.slice(0, 6)}...${value.slice(-4)}` : '-';

export default function App() {
  const [provider, setProvider] = useState(null);
  const [signer, setSigner] = useState(null);
  const [contract, setContract] = useState(null);
  const [account, setAccount] = useState('');
  const [network, setNetwork] = useState('');
  const [mintFee, setMintFee] = useState('-');
  const [mintUri, setMintUri] = useState('ipfs://metadata-example');
  const [updateId, setUpdateId] = useState('');
  const [updateUri, setUpdateUri] = useState('');
  const [tokens, setTokens] = useState([]);
  const [txStatus, setTxStatus] = useState({ type: 'idle', text: 'Kutilyapti' });

  const statusClass = useMemo(() => `tx tx-${txStatus.type}`, [txStatus.type]);

  async function connectWallet() {
    try {
      if (!window.ethereum) throw new Error('Injected wallet topilmadi');
      const browserProvider = new ethers.BrowserProvider(window.ethereum);
      await browserProvider.send('eth_requestAccounts', []);
      const walletSigner = await browserProvider.getSigner();
      const net = await browserProvider.getNetwork();
      const instance = new ethers.Contract(contractConfig.address, contractConfig.abi, walletSigner);

      setProvider(browserProvider);
      setSigner(walletSigner);
      setContract(instance);
      setAccount(await walletSigner.getAddress());
      setNetwork(`${net.name} / ${net.chainId.toString()}`);
      setMintFee(ethers.formatEther(await instance.mintFee()));
      setTxStatus({ type: 'success', text: 'Wallet ulandi' });
    } catch (err) {
      setTxStatus({ type: 'error', text: err.shortMessage || err.message });
    }
  }

  async function loadTokens(instance = contract) {
    try {
      if (!instance) return;
      const total = Number(await instance.nextTokenId());
      const rows = [];
      for (let i = 1; i <= total; i++) {
        const [id, owner, uri, votes] = await instance.getTokenData(i);
        rows.push({ id: Number(id), owner, uri, votes: Number(votes) });
      }
      setTokens(rows);
    } catch (err) {
      setTxStatus({ type: 'error', text: err.shortMessage || err.message });
    }
  }

  async function mint() {
    try {
      if (!contract) return setTxStatus({ type: 'error', text: 'Avval wallet ulang' });
      setTxStatus({ type: 'pending', text: 'Mint yuborilmoqda...' });
      const tx = await contract.mintNFT(mintUri, { value: await contract.mintFee() });
      await tx.wait();
      setTxStatus({ type: 'success', text: `Mint success: ${tx.hash}` });
      await loadTokens(contract);
    } catch (err) {
      setTxStatus({ type: 'error', text: err.shortMessage || err.message });
    }
  }

  async function vote(id) {
    try {
      if (!contract) return setTxStatus({ type: 'error', text: 'Avval wallet ulang' });
      setTxStatus({ type: 'pending', text: `Token #${id} uchun vote yuborilmoqda...` });
      const tx = await contract.vote(id);
      await tx.wait();
      setTxStatus({ type: 'success', text: `Vote success: ${tx.hash}` });
      await loadTokens(contract);
    } catch (err) {
      setTxStatus({ type: 'error', text: err.shortMessage || err.message });
    }
  }

  async function updateToken() {
    try {
      if (!contract) return setTxStatus({ type: 'error', text: 'Avval wallet ulang' });
      setTxStatus({ type: 'pending', text: 'Token URI yangilanmoqda...' });
      const tx = await contract.updateTokenURI(Number(updateId), updateUri);
      await tx.wait();
      setTxStatus({ type: 'success', text: `URI update success: ${tx.hash}` });
      await loadTokens(contract);
    } catch (err) {
      setTxStatus({ type: 'error', text: err.shortMessage || err.message });
    }
  }

  useEffect(() => {
    if (contract) loadTokens(contract);
  }, [contract]);

  useEffect(() => {
    if (!window.ethereum) return;
    const onChange = () => window.location.reload();
    window.ethereum.on('chainChanged', onChange);
    window.ethereum.on('accountsChanged', onChange);
    return () => {
      window.ethereum.removeListener('chainChanged', onChange);
      window.ethereum.removeListener('accountsChanged', onChange);
    };
  }, []);

  return (
    <div className="page">
      <div className="hero">
        <div className="badge">React.js DApp</div>
        <h1>MedMint NFT</h1>
        <p>Mint, vote va metadata update qilish uchun zamonaviy React interfeys.</p>
        <div className="toolbar">
          <button className="btn primary" onClick={connectWallet}>Connect Wallet</button>
          <button className="btn secondary" onClick={() => loadTokens()}>Refresh</button>
        </div>
        <div className="pills">
          <span className="pill">Account: {short(account)}</span>
          <span className="pill">Network: {network || '-'}</span>
          <span className="pill">Mint Fee: {mintFee} ETH</span>
        </div>
      </div>

      <div className="panels">
        <section className="panel">
          <h2>Mint NFT</h2>
          <input value={mintUri} onChange={(e) => setMintUri(e.target.value)} placeholder="ipfs://metadata" />
          <button className="btn primary full" onClick={mint}>Mint</button>
        </section>

        <section className="panel">
          <h2>Update URI</h2>
          <input value={updateId} onChange={(e) => setUpdateId(e.target.value)} placeholder="Token ID" />
          <input value={updateUri} onChange={(e) => setUpdateUri(e.target.value)} placeholder="Yangi URI" />
          <button className="btn secondary full" onClick={updateToken}>Update</button>
        </section>
      </div>

      <div className={statusClass}>Tx status: {txStatus.text}</div>

      <section className="panel">
        <div className="row">
          <h2>NFT Collection</h2>
          <span className="subtle">Jami: {tokens.length}</span>
        </div>
        <div className="cards">
          {tokens.length === 0 ? <p className="subtle">Hozircha token yo‘q.</p> : tokens.map((token) => (
            <article className="token" key={token.id}>
              <div className="token-head">
                <strong>#{token.id}</strong>
                <span>{token.votes} votes</span>
              </div>
              <p><b>Owner:</b> {short(token.owner)}</p>
              <p><b>URI:</b> {token.uri}</p>
              <button className="btn primary full" onClick={() => vote(token.id)}>Vote</button>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}
