const fs = require("fs");
const path = require("path");
const hre = require("hardhat");

async function main() {
  const mintFee = hre.ethers.parseEther("0.001");
  const [deployer] = await hre.ethers.getSigners();

  const Factory = await hre.ethers.getContractFactory("MedMintNFT");
  const contract = await Factory.deploy(deployer.address, mintFee);
  await contract.waitForDeployment();

  const address = await contract.getAddress();
  console.log("MedMintNFT localhost deploy qilindi:", address);

  const artifact = await hre.artifacts.readArtifact("MedMintNFT");
  fs.writeFileSync(
    path.join(__dirname, "..", "frontend-vanilla", "contract-config.js"),
    `window.CONTRACT_CONFIG = ${JSON.stringify({ address, abi: artifact.abi }, null, 2)};`
  );

  fs.writeFileSync(
    path.join(__dirname, "..", "react-dapp", "src", "abi", "contract-config.json"),
    JSON.stringify({ address, abi: artifact.abi }, null, 2)
  );

  console.log("Frontend config yangilandi.");
}

main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
