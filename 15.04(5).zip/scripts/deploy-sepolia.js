const hre = require("hardhat");

async function main() {
  const mintFee = hre.ethers.parseEther("0.001");
  const [deployer] = await hre.ethers.getSigners();

  const Factory = await hre.ethers.getContractFactory("MedMintNFT");
  const contract = await Factory.deploy(deployer.address, mintFee);
  await contract.waitForDeployment();

  console.log("MedMintNFT Sepolia deploy qilindi:", await contract.getAddress());
  console.log("Deployer:", deployer.address);
  console.log("verify:", `npx hardhat verify --network sepolia ${await contract.getAddress()} ${deployer.address} ${mintFee.toString()}`);
}

main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
