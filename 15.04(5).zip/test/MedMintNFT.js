const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("MedMintNFT", function () {
  async function deployFixture() {
    const [owner, user1, user2] = await ethers.getSigners();
    const mintFee = ethers.parseEther("0.001");
    const Factory = await ethers.getContractFactory("MedMintNFT");
    const contract = await Factory.deploy(owner.address, mintFee);
    await contract.waitForDeployment();
    return { contract, owner, user1, user2, mintFee };
  }

  it("mints NFT with fee", async function () {
    const { contract, user1, mintFee } = await deployFixture();
    await expect(contract.connect(user1).mintNFT("ipfs://token-1", { value: mintFee }))
      .to.emit(contract, "NFTMinted");

    expect(await contract.ownerOf(1)).to.equal(user1.address);
    expect(await contract.tokenURI(1)).to.equal("ipfs://token-1");
  });

  it("allows voting once per wallet", async function () {
    const { contract, user1, user2, mintFee } = await deployFixture();
    await contract.connect(user1).mintNFT("ipfs://token-1", { value: mintFee });

    await expect(contract.connect(user2).vote(1)).to.emit(contract, "Voted");
    expect(await contract.voteCount(1)).to.equal(1);

    await expect(contract.connect(user2).vote(1)).to.be.revertedWith("Already voted for this token");
  });

  it("lets only owner withdraw", async function () {
    const { contract, owner, user1, mintFee } = await deployFixture();
    await contract.connect(user1).mintNFT("ipfs://token-1", { value: mintFee });

    await expect(contract.connect(user1).withdraw()).to.be.reverted;
    await expect(contract.connect(owner).withdraw()).to.emit(contract, "FundsWithdrawn");
  });
});
