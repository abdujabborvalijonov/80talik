# EduChain Credential System

Blockchain asosidagi diplom va sertifikatlar registri. Tizim universitetlar, o'quv markazlari, talabalar va ish beruvchilar uchun mo'ljallangan.

## Imkoniyatlar
- Diplom yoki sertifikatni NFT sifatida chiqarish
- Onlayn kurs natijasini blockchain'da qayd etish
- Credential haqiqiyligini token ID yoki hash orqali tekshirish
- Talaba o'z ma'lumotlarini boshqa universitet yoki employer bilan ulashishi
- Barcha credential'larni yagona registrda yuritish
- IPFS metadata va file CID saqlashga tayyor arxitektura

## Tuzilma
- `contracts/` — Solidity smart-kontrakt
- `scripts/` — deploy skriptlari
- `test/` — Hardhat testlari
- `frontend/` — statik DApp interfeys
- `docs/` — reja va arxitektura

## Local ishga tushirish
```bash
npm install
npm run compile
npm run node
```

Yangi terminal:
```bash
npm run deploy:localhost
npm run serve
```

Frontend:
```bash
http://127.0.0.1:8080
```

## Sepolia testnet deploy
`.env.example` ni `.env` ga ko'chiring va qiymatlarni to'ldiring:
```bash
SEPOLIA_RPC_URL=...
PRIVATE_KEY=0x...
```

Keyin:
```bash
npm run deploy:sepolia
```

## GitHub Pages deploy
`frontend/contract-config.js` ichiga testnet contract address va ABI qo'ying. So'ng repo'ni GitHub'ga push qiling. Workflow `main` branch push qilinganda frontendni GitHub Pages'ga joylaydi.

## Vercel deploy
Static frontendni Vercel'ga ulang. Zarur bo'lsa `frontend/` papkani root sifatida tanlang.

## Eslatma
Bu paket GitHub va bepul hosting uchun tayyor konfiguratsiyani o'z ichiga oladi. Lekin haqiqiy GitHub аккаунтga push qilish va haqiqiy serverga chiqarish uchun sizning GitHub/Vercel akkauntingiz va testnet kalitlaringiz kerak bo'ladi.
