// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/token/ERC721/ERC721.sol";
import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/utils/Strings.sol";

contract EduCredentialRegistry is ERC721, Ownable {
    using Strings for uint256;

    enum CredentialType {
        Diploma,
        Certificate,
        CourseResult
    }

    struct Credential {
        uint256 id;
        CredentialType credentialType;
        address student;
        address issuer;
        string title;
        string institution;
        string programName;
        string grade;
        string metadataURI;
        string fileCID;
        bytes32 studentIdHash;
        bytes32 resultHash;
        uint256 issuedAt;
        bool revoked;
    }

    struct CourseRecord {
        uint256 id;
        address student;
        string courseName;
        string scoreText;
        bytes32 resultHash;
        string metadataURI;
        uint256 recordedAt;
        address issuer;
    }

    uint256 private _tokenIds;
    uint256 private _courseRecordIds;

    mapping(address => bool) public authorizedIssuers;
    mapping(uint256 => Credential) private _credentials;
    mapping(address => uint256[]) private _studentCredentialIds;
    mapping(bytes32 => uint256) public credentialIdByResultHash;
    mapping(address => mapping(address => bool)) public studentViewerAccess;
    mapping(address => CourseRecord[]) private _studentCourseRecords;
    uint256[] private _allCredentialIds;

    event IssuerAuthorized(address indexed issuer, bool allowed);
    event CredentialIssued(
        uint256 indexed credentialId,
        address indexed student,
        address indexed issuer,
        CredentialType credentialType,
        string title
    );
    event CredentialRevoked(uint256 indexed credentialId, address indexed issuer);
    event StudentAccessUpdated(address indexed student, address indexed viewer, bool allowed);
    event CourseResultRecorded(
        uint256 indexed courseRecordId,
        address indexed student,
        address indexed issuer,
        string courseName,
        bytes32 resultHash
    );

    modifier onlyAuthorizedIssuer() {
        require(authorizedIssuers[msg.sender] || msg.sender == owner(), "Not authorized issuer");
        _;
    }

    modifier onlyStudentOrApproved(address student) {
        require(
            msg.sender == student || studentViewerAccess[student][msg.sender] || authorizedIssuers[msg.sender] || msg.sender == owner(),
            "Access denied"
        );
        _;
    }

    constructor(address initialOwner) ERC721("EduChain Credential", "EDUC") Ownable(initialOwner) {}

    function authorizeIssuer(address issuer, bool allowed) external onlyOwner {
        authorizedIssuers[issuer] = allowed;
        emit IssuerAuthorized(issuer, allowed);
    }

    function issueCredential(
        address student,
        CredentialType credentialType,
        string calldata title,
        string calldata institution,
        string calldata programName,
        string calldata grade,
        string calldata metadataURI,
        string calldata fileCID,
        bytes32 studentIdHash,
        bytes32 resultHash
    ) external onlyAuthorizedIssuer returns (uint256 credentialId) {
        require(student != address(0), "Invalid student address");
        require(bytes(title).length > 0, "Title required");
        require(bytes(institution).length > 0, "Institution required");
        require(credentialIdByResultHash[resultHash] == 0, "Result hash already used");

        _tokenIds += 1;
        credentialId = _tokenIds;

        _safeMint(student, credentialId);

        _credentials[credentialId] = Credential({
            id: credentialId,
            credentialType: credentialType,
            student: student,
            issuer: msg.sender,
            title: title,
            institution: institution,
            programName: programName,
            grade: grade,
            metadataURI: metadataURI,
            fileCID: fileCID,
            studentIdHash: studentIdHash,
            resultHash: resultHash,
            issuedAt: block.timestamp,
            revoked: false
        });

        _studentCredentialIds[student].push(credentialId);
        credentialIdByResultHash[resultHash] = credentialId;
        _allCredentialIds.push(credentialId);

        emit CredentialIssued(credentialId, student, msg.sender, credentialType, title);
    }

    function recordCourseResult(
        address student,
        string calldata courseName,
        string calldata scoreText,
        bytes32 resultHash,
        string calldata metadataURI
    ) external onlyAuthorizedIssuer returns (uint256 courseRecordId) {
        require(student != address(0), "Invalid student address");
        require(bytes(courseName).length > 0, "Course name required");
        require(bytes(scoreText).length > 0, "Score text required");

        _courseRecordIds += 1;
        courseRecordId = _courseRecordIds;

        _studentCourseRecords[student].push(
            CourseRecord({
                id: courseRecordId,
                student: student,
                courseName: courseName,
                scoreText: scoreText,
                resultHash: resultHash,
                metadataURI: metadataURI,
                recordedAt: block.timestamp,
                issuer: msg.sender
            })
        );

        emit CourseResultRecorded(courseRecordId, student, msg.sender, courseName, resultHash);
    }

    function setViewerAccess(address viewer, bool allowed) external {
        require(viewer != address(0), "Invalid viewer");
        studentViewerAccess[msg.sender][viewer] = allowed;
        emit StudentAccessUpdated(msg.sender, viewer, allowed);
    }

    function revokeCredential(uint256 credentialId) external onlyAuthorizedIssuer {
        require(_ownerOf(credentialId) != address(0), "Credential not found");
        require(!_credentials[credentialId].revoked, "Already revoked");

        _credentials[credentialId].revoked = true;
        emit CredentialRevoked(credentialId, msg.sender);
    }

    function verifyCredential(uint256 credentialId) external view returns (bool valid, string memory status) {
        if (_ownerOf(credentialId) == address(0)) {
            return (false, "Credential not found");
        }
        if (_credentials[credentialId].revoked) {
            return (false, "Credential revoked");
        }
        return (true, "Credential valid");
    }

    function verifyByHash(bytes32 resultHash) external view returns (bool valid, uint256 credentialId, string memory status) {
        credentialId = credentialIdByResultHash[resultHash];
        if (credentialId == 0 || _ownerOf(credentialId) == address(0)) {
            return (false, 0, "Credential not found");
        }
        if (_credentials[credentialId].revoked) {
            return (false, credentialId, "Credential revoked");
        }
        return (true, credentialId, "Credential valid");
    }

    function getCredential(uint256 credentialId) external view returns (Credential memory) {
        require(_ownerOf(credentialId) != address(0), "Credential not found");
        return _credentials[credentialId];
    }

    function getStudentCredentialIds(address student) external view onlyStudentOrApproved(student) returns (uint256[] memory) {
        return _studentCredentialIds[student];
    }

    function getStudentCourseRecords(address student) external view onlyStudentOrApproved(student) returns (CourseRecord[] memory) {
        return _studentCourseRecords[student];
    }

    function totalCredentials() external view returns (uint256) {
        return _allCredentialIds.length;
    }

    function allCredentialIds() external view returns (uint256[] memory) {
        return _allCredentialIds;
    }

    function tokenURI(uint256 tokenId) public view override returns (string memory) {
        require(_ownerOf(tokenId) != address(0), "Credential not found");
        return _credentials[tokenId].metadataURI;
    }
}
