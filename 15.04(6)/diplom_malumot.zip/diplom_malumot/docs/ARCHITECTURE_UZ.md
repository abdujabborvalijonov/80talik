# Smart-kontrakt arxitekturasi

## Kontrakt nomi
EduCredentialRegistry

## Yadro g'oya
Kontrakt ERC-721 ga asoslangan. Har bir diplom, sertifikat yoki kurs natijasi alohida credential NFT hisoblanadi. Fayllarning o'zi zanjirda saqlanmaydi; ular uchun IPFS CID va metadata URI saqlanadi.

## Asosiy obyektlar
- Credential: diplom, sertifikat yoki kurs natijasi NFT
- CourseRecord: talabaga yozilgan kurs natijasi
- Authorized issuer: credential chiqarishga ruxsatli adres
- Viewer access: talabadan ruxsat olgan ish beruvchi yoki universitet

## Muhim mappinglar
- authorizedIssuers[address] => bool
- studentViewerAccess[student][viewer] => bool
- credentialIdByResultHash[bytes32] => uint256
- studentCredentialIds[student] => uint256[]

## Xavfsizlik
- Faqat owner issuer ruxsatini boshqaradi
- Faqat owner yoki ruxsatli issuer credential chiqaradi
- Talaba o'z ma'lumotini ko'rish ruxsatini boshqaradi
- Verify funksiyasi revoked holatini ham tekshiradi
