# EduChain Credential System — Loyiha rejasi

## Maqsad
Talabalarning diplom, sertifikat va onlayn kurs natijalarini blockchain asosida yaratish, tekshirish va markazsiz ko'rinishda ulashish tizimini ishlab chiqish.

## Asosiy modullar
1. Issuer paneli — universitet yoki o'quv markazi credential chiqaradi
2. Student paneli — talaba o'z ma'lumotlarini ko'radi va tashqi ko'ruvchilarga ruxsat beradi
3. Verification paneli — diplom yoki sertifikat haqiqiyligini tekshiradi
4. Course result registry — onlayn kurs natijalari blockchain'da qayd etiladi
5. Unified registry — barcha credential'lar bitta tizimda yuritiladi

## Texnologiyalar
- Solidity + Hardhat
- Ethers.js
- HTML/CSS/JS frontend
- IPFS tayyor model: CID va metadata URI saqlash
- GitHub Pages yoki Vercel uchun statik deploy

## Ishlash oqimi
1. Issuer wallet orqali credential yaratadi
2. Credential NFT sifatida talabaga biriktiriladi
3. Metadata URI va file CID saqlanadi
4. Tekshiruvchi token ID yoki result hash orqali haqiqiylikni tekshiradi
5. Talaba employer yoki boshqa universitetga ruxsat beradi
