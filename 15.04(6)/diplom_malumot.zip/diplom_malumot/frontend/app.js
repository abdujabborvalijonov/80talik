const connectBtn = document.getElementById('connectBtn');
const issueBtn = document.getElementById('issueBtn');
const verifyBtn = document.getElementById('verifyBtn');
const recordBtn = document.getElementById('recordBtn');
const accessBtn = document.getElementById('accessBtn');
const lookupBtn = document.getElementById('lookupBtn');

const accountLabel = document.getElementById('accountLabel');
const networkLabel = document.getElementById('networkLabel');
const contractLabel = document.getElementById('contractLabel');
const txStatus = document.getElementById('txStatus');
const verifyResult = document.getElementById('verifyResult');
const studentResult = document.getElementById('studentResult');

let provider;
let signer;
let contract;

function setStatus(text, kind = '') {
  txStatus.textContent = text;
  txStatus.className = kind;
}

function shortAddress(value) {
  return value ? `${value.slice(0, 6)}...${value.slice(-4)}` : '-';
}

async function connectWallet() {
  try {
    if (!window.ethereum) {
      throw new Error('MetaMask topilmadi');
    }
    provider = new ethers.BrowserProvider(window.ethereum);
    await provider.send('eth_requestAccounts', []);
    signer = await provider.getSigner();
    const network = await provider.getNetwork();
    contract = new ethers.Contract(window.CONTRACT_CONFIG.address, window.CONTRACT_CONFIG.abi, signer);

    accountLabel.textContent = await signer.getAddress();
    networkLabel.textContent = `Chain ID: ${network.chainId}`;
    contractLabel.textContent = shortAddress(window.CONTRACT_CONFIG.address);
    setStatus('Wallet ulandi', 'success');
  } catch (error) {
    setStatus(error.message, 'error');
  }
}

function toHash(input) {
  return ethers.keccak256(ethers.toUtf8Bytes(String(input || '').trim()));
}

async function issueCredential() {
  try {
    if (!contract) throw new Error('Avval wallet ulang');
    setStatus('Tranzaksiya yuborilmoqda...', 'pending');

    const tx = await contract.issueCredential(
      document.getElementById('studentAddress').value.trim(),
      Number(document.getElementById('credentialType').value),
      document.getElementById('title').value.trim(),
      document.getElementById('institution').value.trim(),
      document.getElementById('programName').value.trim(),
      document.getElementById('grade').value.trim(),
      document.getElementById('metadataURI').value.trim(),
      document.getElementById('fileCID').value.trim(),
      toHash(document.getElementById('studentIdHash').value),
      toHash(document.getElementById('resultHash').value)
    );

    setStatus(`Pending: ${tx.hash}`, 'pending');
    await tx.wait();
    setStatus('Credential muvaffaqiyatli yaratildi', 'success');
  } catch (error) {
    setStatus(error.reason || error.shortMessage || error.message, 'error');
  }
}

async function verifyCredential() {
  try {
    if (!contract) throw new Error('Avval wallet ulang');
    const id = Number(document.getElementById('verifyId').value);
    const [valid, status] = await contract.verifyCredential(id);
    verifyResult.textContent = `Natija: ${valid ? 'HAQIQIY' : 'HAQIQIY EMAS'} | ${status}`;
  } catch (error) {
    verifyResult.textContent = `Natija: Xatolik - ${error.reason || error.shortMessage || error.message}`;
  }
}

async function recordCourseResult() {
  try {
    if (!contract) throw new Error('Avval wallet ulang');
    setStatus('Course result yozilmoqda...', 'pending');
    const tx = await contract.recordCourseResult(
      document.getElementById('courseStudent').value.trim(),
      document.getElementById('courseName').value.trim(),
      document.getElementById('courseScore').value.trim(),
      toHash(document.getElementById('courseHash').value),
      document.getElementById('courseMetadata').value.trim()
    );
    setStatus(`Pending: ${tx.hash}`, 'pending');
    await tx.wait();
    setStatus('Course result saqlandi', 'success');
  } catch (error) {
    setStatus(error.reason || error.shortMessage || error.message, 'error');
  }
}

async function setViewerAccess() {
  try {
    if (!contract) throw new Error('Avval wallet ulang');
    const viewer = document.getElementById('viewerAddress').value.trim();
    const allowed = document.getElementById('viewerAllowed').value === 'true';
    setStatus('Ruxsat yangilanmoqda...', 'pending');
    const tx = await contract.setViewerAccess(viewer, allowed);
    setStatus(`Pending: ${tx.hash}`, 'pending');
    await tx.wait();
    setStatus('Ruxsat muvaffaqiyatli saqlandi', 'success');
  } catch (error) {
    setStatus(error.reason || error.shortMessage || error.message, 'error');
  }
}

async function lookupStudentCredentials() {
  try {
    if (!contract) throw new Error('Avval wallet ulang');
    const student = document.getElementById('lookupStudent').value.trim();
    const ids = await contract.getStudentCredentialIds(student);
    studentResult.textContent = JSON.stringify(ids.map(v => Number(v)), null, 2);
  } catch (error) {
    studentResult.textContent = `Xatolik: ${error.reason || error.shortMessage || error.message}`;
  }
}

connectBtn.addEventListener('click', connectWallet);
issueBtn.addEventListener('click', issueCredential);
verifyBtn.addEventListener('click', verifyCredential);
recordBtn.addEventListener('click', recordCourseResult);
accessBtn.addEventListener('click', setViewerAccess);
lookupBtn.addEventListener('click', lookupStudentCredentials);
