window.CONTRACT_CONFIG = {
  address: '0xYourLocalOrTestnetContractAddress',
  abi: [],
  networkName: 'localhost',
  chainId: 31337
};
