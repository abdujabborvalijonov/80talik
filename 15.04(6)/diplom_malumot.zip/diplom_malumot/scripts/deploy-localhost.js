const fs = require('fs');
const path = require('path');
const hre = require('hardhat');

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  console.log('Deploying with:', deployer.address);

  const Factory = await hre.ethers.getContractFactory('EduCredentialRegistry');
  const contract = await Factory.deploy(deployer.address);
  await contract.waitForDeployment();

  const address = await contract.getAddress();
  console.log('EduCredentialRegistry deployed to:', address);

  const artifact = await hre.artifacts.readArtifact('EduCredentialRegistry');
  const cfgPath = path.join(__dirname, '..', 'frontend', 'contract-config.js');
  const content = `window.CONTRACT_CONFIG = ${JSON.stringify({
    address,
    abi: artifact.abi,
    networkName: 'localhost',
    chainId: 31337,
  }, null, 2)};\n`;
  fs.writeFileSync(cfgPath, content);
  console.log('Frontend config saved to frontend/contract-config.js');
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
