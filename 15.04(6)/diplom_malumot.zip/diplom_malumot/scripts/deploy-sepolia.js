const hre = require('hardhat');

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  console.log('Deploying to Sepolia with:', deployer.address);

  const Factory = await hre.ethers.getContractFactory('EduCredentialRegistry');
  const contract = await Factory.deploy(deployer.address);
  await contract.waitForDeployment();

  console.log('EduCredentialRegistry deployed to:', await contract.getAddress());
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
