const { expect } = require('chai');
const { ethers } = require('hardhat');

describe('EduCredentialRegistry', function () {
  async function deployFixture() {
    const [owner, issuer, student, employer] = await ethers.getSigners();
    const Factory = await ethers.getContractFactory('EduCredentialRegistry');
    const contract = await Factory.deploy(owner.address);
    await contract.waitForDeployment();
    await contract.authorizeIssuer(issuer.address, true);
    return { contract, owner, issuer, student, employer };
  }

  it('issues and verifies a credential', async function () {
    const { contract, issuer, student } = await deployFixture();

    const tx = await contract.connect(issuer).issueCredential(
      student.address,
      0,
      'Bachelor Diploma',
      'EduChain University',
      'Computer Science',
      'A',
      'ipfs://metadata/1',
      'bafy-diploma-1',
      ethers.keccak256(ethers.toUtf8Bytes('student-001')),
      ethers.keccak256(ethers.toUtf8Bytes('diploma-001'))
    );
    await tx.wait();

    const [valid, status] = await contract.verifyCredential(1);
    expect(valid).to.equal(true);
    expect(status).to.equal('Credential valid');

    const credential = await contract.getCredential(1);
    expect(credential.student).to.equal(student.address);
    expect(credential.title).to.equal('Bachelor Diploma');
  });

  it('lets student grant access to an employer', async function () {
    const { contract, issuer, student, employer } = await deployFixture();

    await contract.connect(issuer).issueCredential(
      student.address,
      1,
      'Blockchain Certificate',
      'EduChain Academy',
      'Web3 Development',
      '95/100',
      'ipfs://metadata/2',
      'bafy-cert-2',
      ethers.keccak256(ethers.toUtf8Bytes('student-002')),
      ethers.keccak256(ethers.toUtf8Bytes('cert-002'))
    );

    await contract.connect(student).setViewerAccess(employer.address, true);
    const ids = await contract.connect(employer).getStudentCredentialIds(student.address);
    expect(ids.length).to.equal(1);
    expect(ids[0]).to.equal(1n);
  });

  it('records course results and supports revocation', async function () {
    const { contract, issuer, student } = await deployFixture();

    await contract.connect(issuer).recordCourseResult(
      student.address,
      'Smart Contracts 101',
      'Passed',
      ethers.keccak256(ethers.toUtf8Bytes('course-001')),
      'ipfs://course/1'
    );

    await contract.connect(issuer).issueCredential(
      student.address,
      2,
      'Course Completion',
      'EduChain Academy',
      'Smart Contracts 101',
      'Passed',
      'ipfs://metadata/3',
      'bafy-course-3',
      ethers.keccak256(ethers.toUtf8Bytes('student-003')),
      ethers.keccak256(ethers.toUtf8Bytes('course-credential-003'))
    );

    await contract.connect(issuer).revokeCredential(1);
    const [valid, status] = await contract.verifyCredential(1);
    expect(valid).to.equal(false);
    expect(status).to.equal('Credential revoked');
  });
});
