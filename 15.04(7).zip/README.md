# Logistics Blockchain System

Bu loyiha logistika va ta'minot zanjiri uchun oddiy blockchain asosidagi kuzatuv tizimi.

## Asosiy imkoniyatlar

- Mahsulotni tizimga birinchi marta ro'yxatdan o'tkazish
- Mahsulot joylashuvini yangilash
- Yetkazib berish holatini yangilash
- Mahsulot haqiqiyligini tekshirish
- Egalikni o'tkazish: ishlab chiqaruvchi → distribyutor → sotuvchi
- Butun ta'minot zanjirini audit qilish
- Proof-of-Work asosidagi oddiy mining
- REST API va oddiy web interfeys

## Lokal ishga tushirish

```bash
python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Brauzer:
```bash
http://127.0.0.1:5000
```

## Muhim endpointlar

- `POST /api/products/register`
- `POST /api/products/<product_id>/location`
- `POST /api/products/<product_id>/status`
- `POST /api/products/<product_id>/verify`
- `POST /api/products/<product_id>/transfer`
- `GET /api/products/<product_id>/audit`
- `GET /api/audit/full-chain`

## GitHub ga yuklash

```bash
git init
git add .
git commit -m "Initial logistics blockchain project"
git branch -M main
git remote add origin https://github.com/USERNAME/REPO-NAME.git
git push -u origin main
```

## Render ga deploy qilish

1. GitHub ga repo yuklang
2. Render da New Web Service ni tanlang
3. GitHub repo ni ulang
4. Build command: `pip install -r requirements.txt`
5. Start command: `gunicorn app:app`
6. Deploy

## Eslatma

Bu demo loyiha. Production uchun auth, DB, QR/NFC, GPS va role-based access qo'shiladi.
