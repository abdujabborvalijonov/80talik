from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict

from flask import Flask, jsonify, render_template, request

from blockchain import Blockchain

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
CHAIN_FILE = DATA_DIR / "chain.json"

DATA_DIR.mkdir(exist_ok=True)

app = Flask(__name__)
blockchain = Blockchain(difficulty=3)
product_index: Dict[str, Dict[str, Any]] = {}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def rebuild_product_index() -> None:
    product_index.clear()
    for block in blockchain.chain[1:]:
        payload = block.data
        product_id = payload.get("product_id")
        if not product_id:
            continue

        if product_id not in product_index:
            product_index[product_id] = {
                "product_id": product_id,
                "name": payload.get("name"),
                "serial_number": payload.get("serial_number"),
                "manufacturer": payload.get("manufacturer"),
                "current_owner": payload.get("manufacturer"),
                "current_location": payload.get("location"),
                "current_status": "registered",
                "is_authentic": True,
                "last_updated_at": payload.get("created_at"),
                "history": [],
            }

        item = product_index[product_id]
        event_type = payload.get("event_type")
        item["history"].append(payload)

        if event_type == "product_registered":
            item["name"] = payload.get("name")
            item["serial_number"] = payload.get("serial_number")
            item["manufacturer"] = payload.get("manufacturer")
            item["current_owner"] = payload.get("manufacturer")
            item["current_location"] = payload.get("location")
            item["current_status"] = "registered"
            item["is_authentic"] = True
            item["last_updated_at"] = payload.get("created_at")
        elif event_type == "location_updated":
            item["current_location"] = payload.get("new_location")
            item["last_updated_at"] = payload.get("updated_at")
        elif event_type == "delivery_status_updated":
            item["current_status"] = payload.get("delivery_status")
            item["last_updated_at"] = payload.get("updated_at")
        elif event_type == "ownership_transferred":
            item["current_owner"] = payload.get("to_owner")
            item["last_updated_at"] = payload.get("updated_at")
        elif event_type == "authenticity_checked":
            item["is_authentic"] = payload.get("is_authentic", False)
            item["last_updated_at"] = payload.get("checked_at")


def save_chain() -> None:
    with CHAIN_FILE.open("w", encoding="utf-8") as f:
        json.dump(blockchain.to_dict(), f, indent=2, ensure_ascii=False)


def load_chain() -> None:
    global blockchain
    if CHAIN_FILE.exists():
        with CHAIN_FILE.open("r", encoding="utf-8") as f:
            raw = json.load(f)
        blockchain = Blockchain.from_dict(raw)
    else:
        blockchain = Blockchain(difficulty=3)
        seed_demo_data()
        save_chain()
    rebuild_product_index()


def seed_demo_data() -> None:
    if len(blockchain.chain) > 1:
        return

    product_id = "PRD-1001"
    blockchain.add_block({
        "event_type": "product_registered",
        "product_id": product_id,
        "name": "Smart Sensor Box",
        "serial_number": "SN-0001001",
        "manufacturer": "UzTech Manufacturing",
        "location": "Tashkent Factory",
        "created_at": utc_now(),
        "notes": "Product first registered in the logistics blockchain."
    })
    blockchain.add_block({
        "event_type": "location_updated",
        "product_id": product_id,
        "new_location": "Regional Warehouse",
        "updated_at": utc_now(),
        "notes": "GPS/warehouse scan confirmed new location."
    })
    blockchain.add_block({
        "event_type": "delivery_status_updated",
        "product_id": product_id,
        "delivery_status": "in_transit",
        "updated_at": utc_now(),
        "notes": "Shipment left warehouse."
    })
    blockchain.add_block({
        "event_type": "ownership_transferred",
        "product_id": product_id,
        "from_owner": "UzTech Manufacturing",
        "to_owner": "Central Distributor",
        "updated_at": utc_now(),
        "notes": "Ownership transferred to distributor."
    })
    blockchain.add_block({
        "event_type": "authenticity_checked",
        "product_id": product_id,
        "checked_by": "Central Distributor",
        "is_authentic": True,
        "checked_at": utc_now(),
        "notes": "Hash trail verified successfully."
    })


def error_response(message: str, status_code: int = 400):
    return jsonify({"ok": False, "message": message}), status_code


@app.get("/")
def index():
    return render_template("index.html")


@app.get("/api/health")
def health():
    return jsonify({"ok": True, "message": "Logistics blockchain API is running"})


@app.get("/api/blocks")
def get_blocks():
    return jsonify({
        "ok": True,
        "count": len(blockchain.chain),
        "difficulty": blockchain.difficulty,
        "chain_valid": blockchain.is_chain_valid(),
        "blocks": [block.to_dict() for block in blockchain.chain],
    })


@app.get("/api/products")
def list_products():
    return jsonify({
        "ok": True,
        "count": len(product_index),
        "products": list(product_index.values())
    })


@app.get("/api/products/<product_id>")
def get_product(product_id: str):
    item = product_index.get(product_id)
    if not item:
        return error_response("Product not found", 404)
    return jsonify({"ok": True, "product": item})


@app.post("/api/products/register")
def register_product():
    payload = request.get_json(silent=True) or {}
    required = ["product_id", "name", "serial_number", "manufacturer", "location"]
    for key in required:
        if not payload.get(key):
            return error_response(f"Missing field: {key}")

    product_id = payload["product_id"]
    if product_id in product_index:
        return error_response("Product already exists")

    event = {
        "event_type": "product_registered",
        "product_id": product_id,
        "name": payload["name"],
        "serial_number": payload["serial_number"],
        "manufacturer": payload["manufacturer"],
        "location": payload["location"],
        "created_at": utc_now(),
        "notes": payload.get("notes", "Product first registered in the system."),
    }
    block = blockchain.add_block(event)
    rebuild_product_index()
    save_chain()
    return jsonify({"ok": True, "message": "Product registered", "block": block.to_dict()}), 201


@app.post("/api/products/<product_id>/location")
def update_location(product_id: str):
    if product_id not in product_index:
        return error_response("Product not found", 404)
    payload = request.get_json(silent=True) or {}
    new_location = payload.get("new_location")
    if not new_location:
        return error_response("Missing field: new_location")

    event = {
        "event_type": "location_updated",
        "product_id": product_id,
        "previous_location": product_index[product_id].get("current_location"),
        "new_location": new_location,
        "updated_at": utc_now(),
        "notes": payload.get("notes", "Product location updated in real time."),
    }
    block = blockchain.add_block(event)
    rebuild_product_index()
    save_chain()
    return jsonify({"ok": True, "message": "Location updated", "block": block.to_dict()})


@app.post("/api/products/<product_id>/status")
def update_status(product_id: str):
    if product_id not in product_index:
        return error_response("Product not found", 404)
    payload = request.get_json(silent=True) or {}
    delivery_status = payload.get("delivery_status")
    if not delivery_status:
        return error_response("Missing field: delivery_status")

    event = {
        "event_type": "delivery_status_updated",
        "product_id": product_id,
        "delivery_status": delivery_status,
        "updated_at": utc_now(),
        "notes": payload.get("notes", "Delivery status changed."),
    }
    block = blockchain.add_block(event)
    rebuild_product_index()
    save_chain()
    return jsonify({"ok": True, "message": "Delivery status updated", "block": block.to_dict()})


@app.post("/api/products/<product_id>/verify")
def verify_authenticity(product_id: str):
    if product_id not in product_index:
        return error_response("Product not found", 404)

    trail = blockchain.get_product_history(product_id)
    is_authentic = len(trail) > 0 and blockchain.is_chain_valid()
    payload = request.get_json(silent=True) or {}
    checked_by = payload.get("checked_by", "system")

    event = {
        "event_type": "authenticity_checked",
        "product_id": product_id,
        "checked_by": checked_by,
        "is_authentic": is_authentic,
        "checked_at": utc_now(),
        "notes": "Authenticity verified from immutable chain history.",
    }
    block = blockchain.add_block(event)
    rebuild_product_index()
    save_chain()
    return jsonify({
        "ok": True,
        "message": "Authenticity checked",
        "is_authentic": is_authentic,
        "block": block.to_dict(),
    })


@app.post("/api/products/<product_id>/transfer")
def transfer_ownership(product_id: str):
    if product_id not in product_index:
        return error_response("Product not found", 404)
    payload = request.get_json(silent=True) or {}
    to_owner = payload.get("to_owner")
    if not to_owner:
        return error_response("Missing field: to_owner")

    event = {
        "event_type": "ownership_transferred",
        "product_id": product_id,
        "from_owner": product_index[product_id].get("current_owner"),
        "to_owner": to_owner,
        "updated_at": utc_now(),
        "notes": payload.get("notes", "Ownership transferred across the supply chain."),
    }
    block = blockchain.add_block(event)
    rebuild_product_index()
    save_chain()
    return jsonify({"ok": True, "message": "Ownership transferred", "block": block.to_dict()})


@app.get("/api/products/<product_id>/audit")
def audit_product(product_id: str):
    if product_id not in product_index:
        return error_response("Product not found", 404)

    history = blockchain.get_product_history(product_id)
    return jsonify({
        "ok": True,
        "product_id": product_id,
        "chain_valid": blockchain.is_chain_valid(),
        "event_count": len(history),
        "history": history,
    })


@app.get("/api/audit/full-chain")
def full_chain_audit():
    products_summary = []
    for item in product_index.values():
        products_summary.append({
            "product_id": item["product_id"],
            "name": item["name"],
            "current_owner": item["current_owner"],
            "current_location": item["current_location"],
            "current_status": item["current_status"],
            "is_authentic": item["is_authentic"],
            "history_length": len(item["history"]),
        })

    return jsonify({
        "ok": True,
        "chain_valid": blockchain.is_chain_valid(),
        "total_blocks": len(blockchain.chain),
        "total_products": len(product_index),
        "products": products_summary,
    })


if __name__ == "__main__":
    load_chain()
    app.run(debug=True, host="0.0.0.0", port=5000)
else:
    load_chain()
