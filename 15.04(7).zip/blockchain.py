from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class Block:
    index: int
    timestamp: str
    data: Dict[str, Any]
    previous_hash: str
    nonce: int = 0
    hash: str = ""

    def calculate_hash(self) -> str:
        block_string = json.dumps(
            {
                "index": self.index,
                "timestamp": self.timestamp,
                "data": self.data,
                "previous_hash": self.previous_hash,
                "nonce": self.nonce,
            },
            sort_keys=True,
            ensure_ascii=False,
        )
        return hashlib.sha256(block_string.encode("utf-8")).hexdigest()

    def mine_block(self, difficulty: int) -> None:
        target = "0" * difficulty
        self.hash = self.calculate_hash()
        while not self.hash.startswith(target):
            self.nonce += 1
            self.hash = self.calculate_hash()

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, raw: Dict[str, Any]) -> "Block":
        return cls(**raw)


class Blockchain:
    def __init__(self, difficulty: int = 3):
        self.difficulty = difficulty
        self.chain: List[Block] = [self.create_genesis_block()]

    def create_genesis_block(self) -> Block:
        block = Block(
            index=0,
            timestamp=utc_now(),
            data={"event_type": "genesis", "message": "Initial logistics blockchain block"},
            previous_hash="0",
        )
        block.mine_block(self.difficulty)
        return block

    def get_latest_block(self) -> Block:
        return self.chain[-1]

    def add_block(self, data: Dict[str, Any]) -> Block:
        new_block = Block(
            index=len(self.chain),
            timestamp=utc_now(),
            data=data,
            previous_hash=self.get_latest_block().hash,
        )
        new_block.mine_block(self.difficulty)
        self.chain.append(new_block)
        return new_block

    def is_chain_valid(self) -> bool:
        for i in range(1, len(self.chain)):
            current = self.chain[i]
            previous = self.chain[i - 1]

            if current.hash != current.calculate_hash():
                return False

            if current.previous_hash != previous.hash:
                return False

            if not current.hash.startswith("0" * self.difficulty):
                return False
        return True

    def get_product_history(self, product_id: str) -> List[Dict[str, Any]]:
        rows: List[Dict[str, Any]] = []
        for block in self.chain[1:]:
            if block.data.get("product_id") == product_id:
                rows.append(
                    {
                        "block_index": block.index,
                        "timestamp": block.timestamp,
                        "hash": block.hash,
                        "previous_hash": block.previous_hash,
                        "nonce": block.nonce,
                        "data": block.data,
                    }
                )
        return rows

    def to_dict(self) -> Dict[str, Any]:
        return {
            "difficulty": self.difficulty,
            "chain": [block.to_dict() for block in self.chain],
        }

    @classmethod
    def from_dict(cls, raw: Dict[str, Any]) -> "Blockchain":
        obj = cls(difficulty=raw["difficulty"])
        obj.chain = [Block.from_dict(item) for item in raw["chain"]]
        return obj
